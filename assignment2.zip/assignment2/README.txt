README

To run, import the code into netbeans. Place the "Reviews.txt" file into the directory with the source files.

The index page has two buttons - one will take you to a page to import a new review. Simply fill in the boxes and hit Sumbit a new Review", and it will write it to a text file. 

The other page will show you a table of all the current reviews. The text is imported from "Reviews.txt".