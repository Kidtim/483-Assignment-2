/*
This class builds the Reviews list, and creates a category for each thing needed for a review.
 */
package JavaFiles;
import java.io.Serializable;

/**
 *
 * @author Kidtim
 */
public class Reviews implements Serializable{
  
  private String Title;
  private String URL;
  private String ProCon;
  private String Major;
  private String Minor;
  private String Summary;
  private String Score;
  private String Name;
  
  public Reviews() {}
  public Reviews(String Title, String URL, String Summary, String ProCon, String Major, String Minor, String Score, String Name)
  {
      this.Title = Title;
      this.URL = URL;
      this.Summary = Summary;
      this.ProCon = ProCon;
      this.Major = Major;
      this.Minor = Minor;
      this.Score = Score;
      this.Name = Name;
  }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String Title) {
        this.Title = Title;
    }

    public String getURL() {
        return URL;
    }

    public void setURL(String URL) {
        this.URL = URL;
    }

    public String getProCon() {
        return ProCon;
    }

    public void setProCon(String ProCon) {
        this.ProCon = ProCon;
    }

    public String getMajor() {
        return Major;
    }

    public void setMajor(String Major) {
        this.Major = Major;
    }

    public String getMinor() {
        return Minor;
    }

    public void setMinor(String Minor) {
        this.Minor = Minor;
    }

    public String getSummary() {
        return Summary;
    }

    public void setSummary(String Summary) {
        this.Summary = Summary;
    }

    public String getScore() {
        return Score;
    }

    public void setScore(String Score) {
        this.Score = Score;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }
  
  
  
}
