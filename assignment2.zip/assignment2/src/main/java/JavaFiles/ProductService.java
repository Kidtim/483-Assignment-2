/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaFiles;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.annotation.ManagedBean;
import javax.annotation.PostConstruct;
import javax.faces.bean.SessionScoped;
import javax.inject.Named;

@Named
@SessionScoped
@ManagedBean
public class ProductService {

    List<Reviews> review;

    /**
     *
     */
    @PostConstruct
    public void init() {
        review = new ArrayList<>(); //This adds a bunch of junk data to populate the table
        Reviews r1 = new Reviews("Title", "URL", "Summary", "ProCon", "Minor", "Major", "Score", "Name");
        Reviews r2 = new Reviews("Title", "URL", "Summary", "ProCon", "Minor", "Major", "Score", "Name");
        Reviews r3 = new Reviews("Title", "URL", "Summary", "ProCon", "Minor", "Major", "Score", "Name");
        Reviews r4 = new Reviews("Title", "URL", "Summary", "ProCon", "Minor", "Major", "Score", "Name");
        Reviews r5 = new Reviews("Title", "URL", "Summary", "ProCon", "Minor", "Major", "Score", "Name");
        Reviews r6 = new Reviews("Title", "URL", "Summary", "ProCon", "Minor", "Major", "Score", "Name");
        Reviews r7 = new Reviews("Title", "URL", "Summary", "ProCon", "Minor", "Major", "Score", "Name");
        Reviews r8 = new Reviews("Title", "URL", "Summary", "ProCon", "Minor", "Major", "Score", "Name");
        
        review.add(r1);
        review.add(r2);
        review.add(r3);
        review.add(r4);
        review.add(r5);
        review.add(r6);
        review.add(r7);
        review.add(r8);
    }

    public List<Reviews> getReviews() {
        return new ArrayList<>(review);
    }

    public List<Reviews> getReviews(int size) {

        if (size > review.size()) {
            Random rand = new Random();

            List<Reviews> randomList = new ArrayList<>();
            for (int i = 0; i < size; i++) {
                int randomIndex = rand.nextInt(review.size());
                randomList.add(review.get(randomIndex));
            }

            return randomList;
        }

        else {
            return new ArrayList<>(review.subList(0, size));
        }

    }
    public List<Reviews> getClonedProducts(int size) throws CloneNotSupportedException {
		List<Reviews> results = new ArrayList<>();
		List<Reviews> originals = getReviews(size);
		for (Reviews original : originals) {
			review.add(original);
		}
		return results;
	}
}