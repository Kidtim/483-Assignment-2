package JavaFiles;


import JavaFiles.Reviews;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

@Named("dtBasicView")
@ViewScoped
public class BasicView implements Serializable {

    private List<Reviews> review;

    @Inject
    private ProductService service;

    @PostConstruct
    public void init() {
        review = service.getReviews(4);
    }

    public List<Reviews> getReviews() {
        return review;
    }

    public void setService(ProductService service) {
        this.service = service;
    }
}