/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaFiles;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

/**
 *
 * @author Kidtim
 * 
 * This class reads the text file in which all the reviews are stored. Text file needs to be in 
 * the same directory as Write.java and the rest of the classes.
 * The class is called write because i named it before realizing it was going to read, not write a file.
 */
public class Write extends ProductService{
    
    public void main () throws FileNotFoundException 
    {
        String[] FileAdd={};//Create an array to store the data from the file
        Scanner scan = new Scanner(new File("Reveiws.txt")); //file to read
        scan.useDelimiter(Pattern.compile(";")); //break at each ;
        int i = 0;
        while (scan.hasNext()) 
        {
            String logicalLine = scan.next();
            FileAdd[i] = logicalLine; //Set each word, delimited by ;, into an array
            i++;
            if (i%7 == 0) //Every 8 times, add the array to a list, then set i to 0.
            {
                Reviews n1 = new Reviews(FileAdd[0], FileAdd[1], FileAdd[2], FileAdd[3], FileAdd[4], FileAdd[5] ,FileAdd[6] ,FileAdd[7]);
                review.add(n1);
                for (int u = 0; u<7; u++)
                {
                    i--;
                }
            }
            
        }
    }
     
}
